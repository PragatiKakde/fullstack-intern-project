# CodeIgniter Backend

Run `composer install` to setup.
