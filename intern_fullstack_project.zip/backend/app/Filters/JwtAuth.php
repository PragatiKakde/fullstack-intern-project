<?php namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class JwtAuth implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $auth = $request->getHeaderLine('Authorization');
        if (!$auth || !preg_match('/Bearer\s(\S+)/', $auth, $matches)) {
            return service('response')->setStatusCode(401)->setJSON(['error'=>'Authorization header not found']);
        }
        $token = $matches[1];

        $secret = getenv('jwt.secret');
        try {
            $payload = JWT::decode($token, new Key($secret, 'HS256'));
            // attach payload to request
            $request->setGlobal('jwt_payload', (array)$payload);
        } catch (\Exception $e) {
            return service('response')->setStatusCode(401)->setJSON(['error'=>'Invalid token','message'=>$e->getMessage()]);
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {}
}
