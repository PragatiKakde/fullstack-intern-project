<?php namespace Config;

$routes = Services::routes(true);

// Default route setup (minimal)
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

// API group; controllers under App\Controllers\Api namespace
$routes->group('api', ['namespace'=>'App\Controllers\Api'], function($routes){
    $routes->post('auth/register', 'Auth::register');
    $routes->post('auth/login', 'Auth::login');

    // Protected routes (requires jwt filter)
    $routes->get('users', 'UserController::index', ['filter'=>'jwt']);
    $routes->get('teachers', 'TeacherController::index', ['filter'=>'jwt']);
});
