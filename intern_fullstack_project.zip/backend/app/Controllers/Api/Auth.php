<?php namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use App\Models\UserModel;
use App\Models\TeacherModel;
use Firebase\JWT\JWT;

class Auth extends ResourceController
{
    public function register()
    {
        $data = $this->request->getJSON(true);
        $rules = [
            'email'=>'required|valid_email|is_unique[auth_user.email]',
            'first_name'=>'required',
            'password'=>'required|min_length[6]',
            'university_name'=>'required',
            'year_joined'=>'required|numeric|greater_than[1900]'
        ];
        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        }

        $userModel = new UserModel();
        $teacherModel = new TeacherModel();

        $userData = [
            'email'=>$data['email'],
            'first_name'=>$data['first_name'],
            'last_name'=>$data['last_name'] ?? null,
            'password'=>password_hash($data['password'], PASSWORD_BCRYPT)
        ];

        try {
            $db = \Config\Database::connect();
            $db->transStart();

            $userModel->insert($userData);
            $userId = $userModel->getInsertID();

            $teacherData = [
                'user_id'=>$userId,
                'university_name'=>$data['university_name'],
                'gender'=>$data['gender'] ?? 'other',
                'year_joined'=>$data['year_joined'],
                'department'=>$data['department'] ?? null
            ];

            $teacherModel->insert($teacherData);
            $db->transComplete();

            if ($db->transStatus() === FALSE) {
                return $this->failServerError('Unable to create user');
            }

            return $this->respondCreated([
                'message'=>'User and teacher created',
                'user_id'=>$userId
            ]);
        } catch (\Exception $e) {
            return $this->failServerError($e->getMessage());
        }
    }

    public function login()
    {
        $data = $this->request->getJSON(true);
        if (empty($data['email']) || empty($data['password'])) {
            return $this->fail('Email and password required', 400);
        }

        $userModel = new UserModel();
        $user = $userModel->where('email', $data['email'])->first();
        if (!$user) return $this->failNotFound('User not found');

        if (!password_verify($data['password'], $user['password'])) {
            return $this->fail('Invalid credentials', 401);
        }

        $now = time();
        $exp = $now + (int)getenv('jwt.exp');

        $payload = [
            'iss' => getenv('jwt.issuer'),
            'iat' => $now,
            'exp' => $exp,
            'sub' => $user['id'],
            'email' => $user['email']
        ];

        $jwt = JWT::encode($payload, getenv('jwt.secret'), 'HS256');

        return $this->respond([
            'access_token' => $jwt,
            'expires_in' => (int)getenv('jwt.exp'),
            'token_type' => 'Bearer'
        ]);
    }
}
