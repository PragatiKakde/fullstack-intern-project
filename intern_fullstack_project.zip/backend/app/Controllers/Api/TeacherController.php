<?php namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use App\Models\TeacherModel;

class TeacherController extends ResourceController
{
    public function index()
    {
        $model = new TeacherModel();
        $teachers = $model->select('teachers.*, auth_user.email, auth_user.first_name')
                          ->join('auth_user','auth_user.id = teachers.user_id')
                          ->findAll();
        return $this->respond($teachers);
    }
}
