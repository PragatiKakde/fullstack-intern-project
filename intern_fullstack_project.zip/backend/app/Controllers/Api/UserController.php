<?php namespace App\Controllers\Api;
use CodeIgniter\RESTful\ResourceController;
use App\Models\UserModel;

class UserController extends ResourceController
{
    public function index()
    {
        $model = new UserModel();
        $users = $model->select('id, email, first_name, last_name, created_at')->findAll();
        return $this->respond($users);
    }
}
