<?php
class Auth extends CI_Controller { public function register() {} public function login() {} }