<?php
class TeacherModel extends CI_Model {}