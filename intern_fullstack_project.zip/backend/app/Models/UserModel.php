<?php
class UserModel extends CI_Model {}