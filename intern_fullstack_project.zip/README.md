# Fullstack Internship Project

Contains CodeIgniter Backend + React Frontend + SQL Schema.
