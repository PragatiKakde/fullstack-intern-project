# React Frontend

Run `npm install && npm run dev` to start frontend.
