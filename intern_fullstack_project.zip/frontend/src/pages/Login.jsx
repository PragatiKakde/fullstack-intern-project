import React, {useState} from 'react';
import API from '../api';
import { useNavigate } from 'react-router-dom';

export default function Login(){
  const [form, setForm] = useState({});
  const nav = useNavigate();
  const handle = e => setForm({...form, [e.target.name]: e.target.value});
  const submit = async e => {
    e.preventDefault();
    try{
      const { data } = await API.post('/auth/login', form);
      localStorage.setItem('access_token', data.access_token);
      nav('/users');
    } catch(err) {
      alert(JSON.stringify(err.response?.data || err.message));
    }
  }

  return (
    <div className="container">
      <h2>Login</h2>
      <form onSubmit={submit}>
        <input name="email" onChange={handle} placeholder="Email" required/>
        <input name="password" type="password" onChange={handle} placeholder="Password" required/>
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
