import React, {useEffect, useState} from 'react';
import API from '../api';

export default function Teachers(){
  const [items,setItems] = useState([]);
  useEffect(()=> {
    API.get('/teachers')
      .then(r=>setItems(r.data))
      .catch(e=> alert('Fetch failed: ' + JSON.stringify(e.response?.data || e.message)));
  }, []);
  return (
    <div className="container">
      <h2>Teachers</h2>
      <table>
        <thead><tr><th>ID</th><th>User ID</th><th>University</th><th>Year Joined</th></tr></thead>
        <tbody>
        {items.map(t=>(
          <tr key={t.id}>
            <td>{t.id}</td><td>{t.user_id}</td><td>{t.university_name}</td><td>{t.year_joined}</td>
          </tr>
        ))}
        </tbody>
      </table>
    </div>
  );
}
