import React, {useEffect, useState} from 'react';
import API from '../api';

export default function Users(){
  const [users,setUsers] = useState([]);
  useEffect(()=> {
    API.get('/users')
      .then(r=>setUsers(r.data))
      .catch(e=> alert('Fetch failed: ' + JSON.stringify(e.response?.data || e.message)));
  }, []);
  return (
    <div className="container">
      <h2>Users</h2>
      <table>
        <thead><tr><th>ID</th><th>Email</th><th>Name</th></tr></thead>
        <tbody>
        {users.map(u=>(
          <tr key={u.id}>
            <td>{u.id}</td><td>{u.email}</td><td>{u.first_name} {u.last_name}</td>
          </tr>
        ))}
        </tbody>
      </table>
    </div>
  );
}
