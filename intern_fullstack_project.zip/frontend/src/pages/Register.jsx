import React, {useState} from 'react';
import API from '../api';
import { useNavigate } from 'react-router-dom';

export default function Register(){
  const [form, setForm] = useState({});
  const nav = useNavigate();
  const handle = e => setForm({...form, [e.target.name]: e.target.value});
  const submit = async e => {
    e.preventDefault();
    try {
      await API.post('/auth/register', form);
      alert('Created. Please login.');
      nav('/login');
    } catch (err) {
      alert(JSON.stringify(err.response?.data || err.message));
    }
  }

  return (
    <div className="container">
      <h2>Register</h2>
      <form onSubmit={submit}>
        <input name="email" onChange={handle} placeholder="Email" required/>
        <input name="first_name" onChange={handle} placeholder="First name" required/>
        <input name="last_name" onChange={handle} placeholder="Last name"/>
        <input name="password" onChange={handle} placeholder="Password" type="password" required/>
        <input name="university_name" onChange={handle} placeholder="University" required/>
        <input name="year_joined" onChange={handle} placeholder="Year joined" type="number" required/>
        <button type="submit">Register</button>
      </form>
    </div>
  );
}
